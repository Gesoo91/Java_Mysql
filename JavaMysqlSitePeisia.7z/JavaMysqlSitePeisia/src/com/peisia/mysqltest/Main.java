package com.peisia.mysqltest;

import com.peisia.site.SiteMain;

public class Main {
	public static void main(String[] args) {
		SiteMain.run();//기존 게시판에서 site로 확장함
	}
	
	

}